# EduNusa LMS — Prototype UI

## Cara menjalankan
1. Ekstrak ZIP ini.
2. Buka `index.html` dengan browser modern (Chrome, Edge, Firefox).
3. Tidak perlu instalasi atau server untuk fitur demo dasar.

## Fitur
- Dashboard ringkasan, kartu mata kuliah, tugas mendatang, pengumuman.
- Navigasi antarhalaman: Beranda, Mata Kuliah, Tugas, Nilai, Pengumuman, Kalender, Profil.
- Tambah, edit, dan hapus mata kuliah serta tugas.
- Filter status dan mata kuliah, pencarian, indikator tenggat/status.
- Kalender bulanan dan penambahan agenda.
- Tandai pengumuman dibaca.
- Edit profil dan ekspor nilai simulasi ke CSV.
- Penyimpanan data demo di localStorage browser.
- Layout responsif untuk desktop dan ponsel.

## Catatan
Ini adalah prototype front-end untuk tugas Interaksi Manusia dan Komputer (IMK). Semua data mata kuliah, tugas, dan nilai adalah data contoh, bukan terhubung ke server atau sistem resmi kampus. Data tersimpan hanya pada browser/perangkat yang digunakan. Google Fonts memerlukan koneksi internet; bila offline, font cadangan tetap digunakan.
